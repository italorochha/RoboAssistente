package com.italo.RoboAssistente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoboAssistenteApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoboAssistenteApplication.class, args);
	}

}
